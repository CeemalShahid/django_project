from django.apps import AppConfig


class SmartparkConfig(AppConfig):
    name = 'SmartPark'
